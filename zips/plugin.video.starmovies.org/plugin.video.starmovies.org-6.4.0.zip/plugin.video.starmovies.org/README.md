plugin.video.starmovies.org
---------------------------

A Kodi Addon to display and manage themoviedb lists and ratings

Usage
-----

Settings:
---------

Installation
------------

 - Download the add-on as a ZIP file from the top of this page
 - Open Kodi
 - Go to `System -> Settings -> Add-ons -> Install from zip file`
 - Restart Kodi and enjoy :)
 
Release history
---------------
  * 2016-09-01 v 1.0.1 Initial release
  6.0.0 - Kodi 19
  6.2.0 - Set user agent
