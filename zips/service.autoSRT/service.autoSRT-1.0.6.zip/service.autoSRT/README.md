service.autoSRT
===============

Auto trigger XBMC Subtitle download if no SRT subtitle file is found for a Movie/TV Show.<br>

Configuration options:
- Exclude media paths
- Exclude certain words
- Only trigger for specific language
